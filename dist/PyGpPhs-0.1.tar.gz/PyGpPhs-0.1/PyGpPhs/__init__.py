# __init__.py file
from .model import Model